/*
 * LEGO_I2C_Test.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "LEGO_I2C_Test".
 *
 * Model version              : 1.2
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Mon Nov  2 13:32:16 2020
 *
 * Target selection: ert.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: ARM Compatible->ARM 9
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_LEGO_I2C_Test_h_
#define RTW_HEADER_LEGO_I2C_Test_h_
#include <stddef.h>
#include <string.h>
#ifndef LEGO_I2C_Test_COMMON_INCLUDES_
#define LEGO_I2C_Test_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "driver_ev3.h"
#endif                                 /* LEGO_I2C_Test_COMMON_INCLUDES_ */

#include "LEGO_I2C_Test_types.h"

/* Shared type includes */
#include "multiword_types.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

/* Block states (default storage) for system '<Root>' */
typedef struct {
  ev3_I2CRead_LEGO_I2C_Test_T obj;     /* '<Root>/I2C Register Read' */
  boolean_T objisempty;                /* '<Root>/I2C Register Read' */
} DW_LEGO_I2C_Test_T;

/* Real-time Model Data Structure */
struct tag_RTM_LEGO_I2C_Test_T {
  const char_T *errorStatus;
};

/* Block states (default storage) */
extern DW_LEGO_I2C_Test_T LEGO_I2C_Test_DW;

/* Model entry point functions */
extern void LEGO_I2C_Test_initialize(void);
extern void LEGO_I2C_Test_step(void);
extern void LEGO_I2C_Test_terminate(void);

/* Real-time Model object */
extern RT_MODEL_LEGO_I2C_Test_T *const LEGO_I2C_Test_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'LEGO_I2C_Test'
 * '<S1>'   : 'LEGO_I2C_Test/Display'
 * '<S2>'   : 'LEGO_I2C_Test/Display1'
 */
#endif                                 /* RTW_HEADER_LEGO_I2C_Test_h_ */
