/*
 * LEGO_I2C_Test_types.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "LEGO_I2C_Test".
 *
 * Model version              : 1.2
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Mon Nov  2 13:32:16 2020
 *
 * Target selection: ert.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: ARM Compatible->ARM 9
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_LEGO_I2C_Test_types_h_
#define RTW_HEADER_LEGO_I2C_Test_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"

/* Model Code Variants */
#ifndef struct_tag_MfrkK8JA1OlJzsQQ70jHGH
#define struct_tag_MfrkK8JA1OlJzsQQ70jHGH

struct tag_MfrkK8JA1OlJzsQQ70jHGH
{
  boolean_T matlabCodegenIsDeleted;
  int32_T isInitialized;
  boolean_T isSetupComplete;
};

#endif                                 /*struct_tag_MfrkK8JA1OlJzsQQ70jHGH*/

#ifndef typedef_ev3_I2CRead_LEGO_I2C_Test_T
#define typedef_ev3_I2CRead_LEGO_I2C_Test_T

typedef struct tag_MfrkK8JA1OlJzsQQ70jHGH ev3_I2CRead_LEGO_I2C_Test_T;

#endif                                 /*typedef_ev3_I2CRead_LEGO_I2C_Test_T*/

/* Forward declaration for rtModel */
typedef struct tag_RTM_LEGO_I2C_Test_T RT_MODEL_LEGO_I2C_Test_T;

#endif                                 /* RTW_HEADER_LEGO_I2C_Test_types_h_ */
