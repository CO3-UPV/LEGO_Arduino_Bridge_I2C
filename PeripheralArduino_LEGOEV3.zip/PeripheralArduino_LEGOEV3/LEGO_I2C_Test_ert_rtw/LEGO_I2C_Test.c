/*
 * LEGO_I2C_Test.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "LEGO_I2C_Test".
 *
 * Model version              : 1.2
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Mon Nov  2 13:32:16 2020
 *
 * Target selection: ert.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: ARM Compatible->ARM 9
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "LEGO_I2C_Test.h"
#include "LEGO_I2C_Test_private.h"

/* Block states (default storage) */
DW_LEGO_I2C_Test_T LEGO_I2C_Test_DW;

/* Real-time model */
static RT_MODEL_LEGO_I2C_Test_T LEGO_I2C_Test_M_;
RT_MODEL_LEGO_I2C_Test_T *const LEGO_I2C_Test_M = &LEGO_I2C_Test_M_;

/* Model step function */
void LEGO_I2C_Test_step(void)
{
  uint8_T i2cData;
  uint8_T status;
  uint8_T tmp;

  /* MATLABSystem: '<Root>/I2C Register Read' */
  readI2CValues(4, 1, &i2cData, &status);

  /* S-Function (ev3_lcd): '<S1>/LCD' incorporates:
   *  DataTypeConversion: '<S1>/Data Type Conversion'
   *  MATLABSystem: '<Root>/I2C Register Read'
   */
  tmp = 0U;
  lcdDisplay(i2cData, &tmp, 1U, 1U);

  /* S-Function (ev3_lcd): '<S2>/LCD' incorporates:
   *  DataTypeConversion: '<S2>/Data Type Conversion'
   *  MATLABSystem: '<Root>/I2C Register Read'
   */
  tmp = 0U;
  lcdDisplay(status, &tmp, 2U, 1U);
}

/* Model initialize function */
void LEGO_I2C_Test_initialize(void)
{
  /* Registration code */

  /* initialize error status */
  rtmSetErrorStatus(LEGO_I2C_Test_M, (NULL));

  /* states (dwork) */
  (void) memset((void *)&LEGO_I2C_Test_DW, 0,
                sizeof(DW_LEGO_I2C_Test_T));

  /* Start for MATLABSystem: '<Root>/I2C Register Read' */
  LEGO_I2C_Test_DW.obj.matlabCodegenIsDeleted = false;
  LEGO_I2C_Test_DW.objisempty = true;
  LEGO_I2C_Test_DW.obj.isInitialized = 1;
  initI2CRead(4, 10, 0, 1, 1000);
  LEGO_I2C_Test_DW.obj.isSetupComplete = true;

  /* Start for S-Function (ev3_lcd): '<S1>/LCD' */
  initLCD();

  /* Start for S-Function (ev3_lcd): '<S2>/LCD' */
  initLCD();
}

/* Model terminate function */
void LEGO_I2C_Test_terminate(void)
{
  /* Terminate for MATLABSystem: '<Root>/I2C Register Read' */
  if (!LEGO_I2C_Test_DW.obj.matlabCodegenIsDeleted) {
    LEGO_I2C_Test_DW.obj.matlabCodegenIsDeleted = true;
    if ((LEGO_I2C_Test_DW.obj.isInitialized == 1) &&
        LEGO_I2C_Test_DW.obj.isSetupComplete) {
      terminateI2CRead(4);
    }
  }

  /* End of Terminate for MATLABSystem: '<Root>/I2C Register Read' */

  /* Terminate for S-Function (ev3_lcd): '<S1>/LCD' */
  terminateLCD();

  /* Terminate for S-Function (ev3_lcd): '<S2>/LCD' */
  terminateLCD();
}
